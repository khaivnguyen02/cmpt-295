/* 
 * Filename: times.c
 *
 * Description: Funtion "times(x,y)" multiplies its two parameters and return the product.
 *              Used as part of our Lab 1.
 *
 * Auhtor:
 * Modification date: Jan. 2023
 */  

int times(int x, int y) {
  int result = x * y;
  return result;
}

